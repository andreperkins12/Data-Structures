#include <string>
#include <iostream>

using namespace std;


class theGameOfLife
{



public:
	theGameOfLife();
	~theGameOfLife();



private:

	
};