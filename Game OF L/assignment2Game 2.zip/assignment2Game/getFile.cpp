#include <string>
#include <iostream>
#include <fstream>
#include "getFile.h"
#include "gameModes.h"
#include "gameBoards.h"


using namespace std;


getFile::getFile(){

}

getFile::~getFile(){


}
/*
bool getFile::gimmeMyArray(string textfile){ ////DEBUGGGGGG

ifstream myfile;
myfile.open(textFile);

int storer = 0;
char placer;



if(!myfile.fail()){

	myfile >> column;
	myfile >> row;
  
  for(int i = 0; i < column; ++i){
    for(int j = 0; j < row; ++j){
      myfile >> placer;
      if(placer == 'X'){
        storer = 1;
      }
      else if(placer == '-'){
        storer = 0;
      }
      else{
        break;
      }
      platform[i][j]=storer;
    }
  }
  myfile.close();
  cout << "Your file has been stored" << endl;
  return true;
  
}
else{
  cout<< "Unable to open file!"<< endl;
  myfile.clear();
  return false;
}

}

///////// GOD DAMNIT DREW DEBUGGG
*/


void getFile::takeInFile(string textfile){    //READING FROM FILE
    ifstream infile;
   
    infile.open (textfile, std::ifstream::in);

    string theLine;
    int lineCount = 0;
    int storer = 0;
    char placer;

    while (getline(infile, theLine)) {

        if (lineCount == 0) {
            theRow = stoi(theLine); //converts string to integer
        }

        if (lineCount == 1) {

            theCol = stoi(theLine);
        }

        lineCount++;
    }

    infile.close();

    



    // set file grid to our GRID
    infile.open (textfile, std::ifstream::in);
    lineCount = 0;


    while (getline(infile, theLine)) {

        if (lineCount == 2) {

            for(int i = 0; i < theCol; ++i){

                for(int j = 0; j < theRow; ++j){

                    int theFileBoard[i][j];

                      infile >> placer;

                      if(placer == 'X'){

                          storer = 1;
                       }
                          else if(placer == '-'){

                            storer = 0;
                          }
                  else{

                        break;
                      }

                  theFileBoard[i][j] = storer; 

                  cout << theFileBoard[i][j] << " "; //print out file board
              }

              cout << endl;  //end of print out file board
              
            } //END OF FOR LOOPS

            
        }

        lineCount++;
    }

    infile.close();


}



int getFile::getRow(string textFile){

	ifstream theFile;
	int row;


	theFile.open(textFile);

	if(theFile.is_open()){

		while(theFile >> row){
			theCount++;
			if (theCount == 1)
			{
				cin >> row ;
			}
		}
	}


	return row;
}

int getFile::getColumn(string textFile){

int col = 5;

return col;
}