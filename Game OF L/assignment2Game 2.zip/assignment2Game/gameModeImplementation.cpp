#include <string>
#include <iostream>
#include <queue>
#include <math.h>
#include "gameModes.h"

using namespace std;

gameModes::gameModes(){ //Construcutor

cout << "Welcome to the Game of Life!" << endl;


}

gameModes::~gameModes(){ //Destroyed
    
}



void gameModes::theClassicMode(int theRow, int theColumn){ ///the Classic Mode DONE
    char theBoard[theRow][theColumn];
    char theCopyBoard[theRow][theColumn];
    
    //BIG O: Quadratic
    for (int i= 0; i < theRow; ++i){
       
        for(int j = 0; j < theColumn; ++j){
            
            theBoard[i][j] = '~' ;
            theCopyBoard[i][j] = theBoard[i][j];
            cout  << theBoard[i][j] << " "; 
        }
         cout << endl;  
    }
    
}



void gameModes::theDoughnutMode(int theRow, int theColumn, double thePopulation, char stopBetween){ //DoughNut Mode //NOT DONE
    char theChoice;
    bool toStop;
    char theResponse;
    char theBoard[theRow][theColumn];  //theBoard
    char theCopyBoard[theRow][theColumn];   //Copy Board
   
 // while(!toStop){

    do {
        if(thePopulation > 0 || thePopulation < 1){
            for (int i= 0; i < theRow; ++i){
                for(int j = 0; j < theColumn; ++j){
                       theBoard[i][j] = '-';                
                       double between0and1 = ((double)rand() /  RAND_MAX);

                       if(between0and1 <= thePopulation){

                           theBoard[i][j] = 'X';

                               } else {
                                    theBoard[i][j] = '~';
                               }
                      //GET THE INDEXES AND STORE 
                    /*

                     if(topLeft){
                          count += theColumn[0][]
                        }else if()
                        
                        
                        
                        for(int foundWaldo = 0; foundWaldo < 8; foundWaldo){ //8 is for possbile points (left, right etccc)
                          int totalSurroundingCells = 0;
                          //ORIGIN UNNECESSARY
                          //ONLY USE TO ACTUALLY CARRY ON
                          //if(theBoard[i] && theBoard[j] == "X")
                            
                          
                          if (theBoard[i - 1] && theBoard[j - 1] == 'X'){
                            totalSurroundingCells+=1;
                            
                          }
                          if (theBoard[i + 1] && theBoard[j + 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          if (theBoard[i - 1] && theBoard[j + 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          if (theBoard[i] && theBoard[j - 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          
                          if (theBoard[i] && theBoard[j + 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          if (theBoard[i + 1] && theBoard[j + 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          if (theBoard[i + 1] && theBoard[j] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          if (theBoard[i + 1] && theBoard[j + 1] == 'X'){
                            totalSurroundingCells+=1;
                          }
                          
                          
                          
                          
                        }












*/
         
                      cout  << theBoard[i][j] << " "; 
                      theCopyBoard[i][j] = theBoard[i][j];
                         
                      }         
             cout << endl;  
            }    
        }

        if (stopBetween == 'Y')
                  {
                    toStop = true;
                    
                      cout << "Would you like to continue (Y/N) " << endl;
                          cin >> theChoice;

                      if (theChoice == 'Y')
                      {
                          toStop = true;
                        } else if (theChoice == 'N'){
                          toStop = false;
                        break;
                        }

                }else {
                     toStop = false;
                     break;
                       }

             } while(toStop);         
  //  }
  
  
}






//THE MIRROR
void gameModes::theMirrorMode(int theRow, int theColumn, double thePopulation, char stopBetween){

    char theChoice;
    bool toStop;
    
    char theResponse;
    char theBoard[theRow][theColumn];
    char theCopyBoard[theRow][theColumn];
    bool leftSide;
    bool rightSide;
    bool topRight;
    bool topLeft;
    bool bottomSide;
    bool topSide;
    bool bottomLeft;
    bool bottomRight;
    bool theBottom;


    //NEED SHADE BLOCK in STATIC POSITION 

    //BIG O: Quadratic

    

        

 // while(!toStop){

    do {

  if(thePopulation > 0 || thePopulation < 1){
   ///
        for (int i= 0; i < theRow; ++i){

            for(int j = 0; j < theColumn; ++j){
                    bool cornerleftSide;
                    bool cornerrightSide;
                    bool cornertopRight;
                    bool cornertopLeft;
                    bool cornerbottomSide;
                    bool cornertopSide;
                    bool cornerbottomLeft;
                    bool cornerbottomRight;
 
                  theBoard[i][j] = '-';
                  
             
                  double between0and1 = ((double)rand() /  RAND_MAX);

                   if(between0and1 <= thePopulation){

                    theBoard[i][j] = 'X';
                                    
                    } else {
                       theBoard[i][j] = '-';
                    } //


                      //GET THE INDEXES AND STORE 

                        int incrementEight = 0;
                        
                        while(incrementEight < 8){ //8 is for possbile points (left, right etccc)
                          int totalSurroundingCells = 0;
                          //ORIGIN UNNECESSARY
                          //ONLY USE TO ACTUALLY CARRY ON
                          //if(theBoard[i] && theBoard[j] == "X")
                          char topLeftB[i][j];
                          char topRightB[i][j];
                          char bottomLeftB[i][j];
                          char bottomRightB[i][j];
                          char leftColumnB[i][j];
                          char rightColumnB[i][j];
                          char topRowB[i][j];
                          char bottomRowB[i][j];

                          topLeftB[i][j] = theBoard[0][0];
                          topRightB[i][j] = theBoard[0][theColumn];
                          bottomLeftB[i][j] = theBoard[theRow][0];
                          bottomRightB[i][j] = theBoard[theRow][theColumn];
                          
                           leftColumnB[i][j] = theBoard[i][0];
                           rightColumnB[i][j] = theBoard[i][theColumn];
                           topRowB[i][j] = theBoard[0][j];
                           bottomRowB[i][j] = theBoard[theRow][j];
                          
                          //left column
                          if(theBoard[i][j] == theBoard[i][0]){
                            
                              theCopyBoard[i][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            
                            //topleft
                            if(theBoard[i][j] == theBoard[0][0]){
                              
                                theCopyBoard[theRow][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            //bottomleft
                            else if(theBoard[i][j] == theBoard[theRow][0]){
                              
                                theCopyBoard[theRow][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            //full left column besides the topleft and bottomleft
                            else{
                              
                            }
                          }
                          
                          
                          //rightColumn
                          if(theBoard[i][j] == theBoard[i][theColumn]){
                            
                              theCopyBoard[i][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            
                            //topRight
                            if(theBoard[i][j] == theBoard[0][theColumn]){
                              
                              theCopyBoard[theRow][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            
                            //bottomRight
                            else if(theBoard[i][j] == theBoard[theRow][theColumn]){
                                theCopyBoard[theRow][theColumn] = 'X';
                                theBoard[i][j] = theCopyBoard[i][j];
                            }
                            else{
                              
                            }
                          }
                          
                          //TopRow
                          if(theBoard[i][j] == theBoard[0][j]){
                            
                              theCopyBoard[theRow][j] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            
                            //TopLeft
                            if(theBoard[i][j] == theBoard[0][0]){
                                theCopyBoard[theRow][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            //TopRight
                            else if(theBoard[i][j] == theBoard[0][theColumn]){
                                theCopyBoard[theRow][0] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            else{
                              
                            }
                          }   
                          
                          //BottomRow
                          if(theBoard[i][j] == theBoard[theRow][j]){
                            
                              theCopyBoard[0][j] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            //BottomLeft
                            if(theBoard[i][j] == theBoard[theRow][0]){
                              
                                theCopyBoard[0][theColumn] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            //BottomRight
                            else if(theBoard[i][j] == theBoard[theRow][theColumn]){
                              
                                theCopyBoard[0][0] = 'X';
                              theBoard[i][j] = theCopyBoard[i][j];
                            }
                            
                            else{
                              
                            }
                          }   
                          
                          if (theBoard[i - 1][j - 1] == 'X'){
                            totalSurroundingCells+=1;
                            topLeft = true;
                            
                          }
                          if (theBoard[i + 1][j + 1] == 'X'){
                            totalSurroundingCells+=1;
                            bottomRight = true;
                          }
                          if (theBoard[i - 1][j + 1] == 'X'){
                            totalSurroundingCells+=1;
                            topRight = true;
                          }
                          if (theBoard[i][j - 1] == 'X'){
                            totalSurroundingCells+=1;
                            leftSide = true;
                          }
                          
                          if (theBoard[i][j + 1] == 'X'){
                            totalSurroundingCells+=1;
                            rightSide = true;
                          }
                          if (theBoard[i + 1][j - 1] == 'X'){
                            totalSurroundingCells+=1;
                            bottomLeft = true;
                            
                          }
                          if (theBoard[i + 1][j] == 'X'){
                            totalSurroundingCells+=1;
                            theBottom = true;
                          }
                          if (theBoard[i + 1][j + 1] == 'X'){
                            totalSurroundingCells+=1;
                            topLeft = true;
                          }
                          
                       if(totalSurroundingCells < 3){
                         //LET DIE
                         theCopyBoard[i][j] = '-';
                         
                         
                       } else if (totalSurroundingCells == 3){
                         //LET LIVE
                         theCopyBoard[i][j] = 'X';
                       }
                       else{
                         //LET DIE
                         theCopyBoard[i][j] = '-';
                       }
                          
                          theBoard[i][j] = theCopyBoard[i][j];
                        }
                        bool stable = true;
                        bool empty = true;

                        if(theBoard[i][j] == 'X' ){ //or has bacteria
                        
                          empty = false;
                          
                             }else if (theBoard[i][j] != theCopyBoard[i][j]){
                               
                                stable = false;
                        }

      
                      cout  << theBoard[i][j] << " "; 
                      theCopyBoard[i][j] = theBoard[i][j];
                         
                      }         

            cout << endl;  
            }    
        }

        if (stopBetween == 'Y')
                  {
                    toStop = true;
                    
              cout << "Would you like to continue (Y/N) " << endl;
                      cin >> theChoice;

                      if (theChoice == 'Y')
                      {
                          toStop = true;
                      } else if (theChoice == 'N'){
                        toStop = false;
                        break;
                      }



                }else { ///Continunous Simulation
                     toStop = false;
                     
                     
                     
                     break;
                       }
                       
                       
                     
                       

        
             } while(toStop);         
  //  }
  
  
}


























