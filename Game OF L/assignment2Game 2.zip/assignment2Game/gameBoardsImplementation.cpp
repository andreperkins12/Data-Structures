#include <string>
#include <iostream>

#include "gameBoards.h"

gameBoards::gameBoards(){

}

gameBoards::~gameBoards(){

}


void gameBoards::originalBoard(int r, int c){


}


void gameBoards::secondBoard(int r, int c){



}