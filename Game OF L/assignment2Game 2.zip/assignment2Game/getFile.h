#include <string>
#include <iostream>


using namespace std; 

class getFile
{
public:
	getFile();
	~getFile();

	int getRow(string textFile);
	int getColumn(string textFile);
	bool gimmeMyArray(string text);

	void takeInFile(string theFile);

	int theCount;
	int theRow;
	int theCol;


private:

	
};
