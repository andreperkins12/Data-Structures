#include <string>
#include <iostream>

class gameModes

{
public:
	gameModes();
	~gameModes();

	void theClassicMode(int row, int column);
	void theDoughnutMode(int row, int column, double pop, char toC);
	void theMirrorMode(int row, int column, double pop, char toC);



private:

	
};