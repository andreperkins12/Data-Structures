
#include <string>
#include <iostream>

using namespace std;

class gameBoards

{

public:
	gameBoards();
	~gameBoards();
	int theRow;
	int theCol;
	void originalBoard(int theR, int theC);

	void secondBoard(int theR, int theC);


private:
	
	
};