#include <string>
#include <iostream>
#include <fstream>

#include "theGameHeader.h"
#include "gameBoards.h"
#include "gameModes.h"
#include "getFile.h"


using namespace std;

int main(int argc, char const *argv[])
{
	gameModes theModes;
	getFile ohMyFiles;
	string theAnswer;
	int theMode;
	int theRow;
	int theCol;
	double decimalValue;
	int fileNumber;
	char toContinue;


	cout<< "Would you like to enter a Map File (Y)es or (N)o (No will generate a random Assignment): "<< endl;
		cin >> theAnswer;

	if (theAnswer == "Y" || theAnswer == "y")
	{
		
		if (argv[1] == NULL) {
			string theFile;

			cout << "Enter File Name: " << endl;
		
		return 1;
	}
		ohMyFiles.getRow(argv[1]);

			cout << "1)Classic Mode \n2)Doughnut mode\n3)Mirror Mode\nChoose your Mode: " << endl;
				cin >> theMode;

			if (theMode == 1)
			{
				theModes.theClassicMode(theRow, theCol);

				} else if (theMode == 2){
				
					theModes.theDoughnutMode(theRow,theCol, decimalValue, toContinue);

					} else if (theMode == 3){

					theModes.theMirrorMode(theRow,theCol, decimalValue, toContinue);

					}  else {

						throw std::out_of_range ("ERROR, Index out of Range for Mode !, Run Again");
					}
				
	




	//DOESNT TAKE IN FILE
			} else if (theAnswer == "N" || theAnswer == "n"){
				
			
						
						cout << "1)Classic Mode \n2)Doughnut mode\n3)Mirror Mode\nChoose your Mode: " << endl;
							cin >> theMode;

						cout << "Would you like to Stop between generations (Y/N) : " << endl;
							cin >> toContinue;

							cout << "Enter # of Rows (MAX : 1000): " << endl;
								cin >> theRow;

							cout << "Enter # of Columns(MAX: 1000): " << endl;
								cin >> theCol;

							cout << "Enter Decimale Value for Population: " << endl;	
								cin >> decimalValue;

								if(theRow >= 1000 || theCol >= 1000 || theMode > 3)
								{
									throw std::out_of_range ("ERROR, Index out of Range for Row, Column, or Mode !, Run Again");
								}
								

							if (theMode == 1)
							{
								theModes.theClassicMode(theRow, theCol);

									} else if (theMode == 2){
				
									theModes.theDoughnutMode(theRow,theCol, decimalValue, toContinue);

							} 	else {

								theModes.theMirrorMode(theRow,theCol, decimalValue, toContinue);

								}

			}

	return 0;
}

